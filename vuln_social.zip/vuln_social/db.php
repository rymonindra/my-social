<?php
// ===================================================
// db.php — Database Connection
// EDUCATIONAL USE ONLY — Intentionally Vulnerable
// ===================================================

$host = "localhost";
$user = "root";
$pass = "";
$db   = "vuln_social";

// Raw mysqli connection — no PDO, no prepared statements
$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("DB Connection Failed: " . mysqli_connect_error());
}

session_start();
