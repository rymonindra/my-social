<?php
// ===================================================
// login.php
// VULNERABILITY: SQL Injection (SQLi)
// Test: username = admin' OR '1'='1'-- -
//       password = anything
// Also works with sqlmap: sqlmap -u "http://localhost/vuln_social/login.php"
//         --data="username=admin&password=test" --dbs
// ===================================================
require_once 'db.php';

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username']; // ❌ No sanitization
    $password = $_POST['password']; // ❌ No sanitization

    // ❌ VULNERABLE QUERY — Direct string interpolation
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";

    // Uncomment below to see the raw SQL (for learning):
    // echo "<pre>SQL: $query</pre>";

    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];
        header("Location: feed.php");
        exit();
    } else {
        $error = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>VulnSocial — Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="auth-wrapper">
    <div class="auth-box">
        <div class="logo">🔓 VulnSocial</div>
        <p class="tagline">Connect. Share. (Demo Only)</p>

        <?php if ($error): ?>
            <div class="alert error"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" placeholder="Enter username" autocomplete="off">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Enter password">
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>

        <div class="auth-footer">
            Don't have an account? <a href="register.php">Register</a>
        </div>

        <!-- HINT BOX for educational purpose -->
        <div class="vuln-hint">
            <strong>🔴 SQLi Hint:</strong><br>
            URL: <code>login.php</code> — POST params: <code>username</code>, <code>password</code><br>
            Try: <code>admin' OR '1'='1'-- -</code> as username
        </div>
    </div>
</div>
</body>
</html>
