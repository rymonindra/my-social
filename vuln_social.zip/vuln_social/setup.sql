-- ===================================================
-- setup.sql — Run this once to create the database
-- EDUCATIONAL USE ONLY — Intentionally Vulnerable
-- ===================================================

CREATE DATABASE IF NOT EXISTS vuln_social;
USE vuln_social;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    password VARCHAR(255),
    email VARCHAR(150),
    bio TEXT,
    role VARCHAR(20) DEFAULT 'user'
);

-- Posts table
CREATE TABLE IF NOT EXISTS posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    content TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    from_user INT,
    to_user INT,
    body TEXT,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed users (password = "password123" plain text — no hashing, intentional)
INSERT INTO users (username, password, email, bio, role) VALUES
('admin',    'admin123',    'admin@social.com',   'Site Administrator', 'admin'),
('alice',    'alice123',    'alice@social.com',   'Hello I am Alice!',  'user'),
('bob',      'bob123',      'bob@social.com',     'Bob here.',          'user'),
('charlie',  'charlie123',  'charlie@social.com', 'Just a regular user.', 'user');

-- Seed posts
INSERT INTO posts (user_id, content) VALUES
(1, 'Welcome to VulnSocial! This is a demo site.'),
(2, 'Alice''s first post! Hello world!'),
(3, 'Bob checking in. What''s up everyone?');
