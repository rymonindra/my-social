<?php
// ===================================================
// feed.php — Home Feed
// VULNERABILITY 1: Reflected XSS via ?search= parameter
// VULNERABILITY 2: SQLi via search parameter
// VULNERABILITY 3: Stored XSS via post content
// VULNERABILITY 4: CSRF on post form (no CSRF token)
//
// SQLi Test URL:
//   feed.php?search=test' UNION SELECT 1,username,password,email,bio,role FROM users-- -
//
// Reflected XSS Test URL:
//   feed.php?search=<script>alert('XSS')</script>
// ===================================================
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];
$user_id  = $_SESSION['user_id'];

// Handle new post — ❌ No CSRF token check
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['content'])) {
    $content = $_POST['content']; // ❌ Stored XSS — no sanitization
    mysqli_query($conn, "INSERT INTO posts (user_id, content) VALUES ($user_id, '$content')");
    header("Location: feed.php");
    exit();
}

// ❌ Reflected XSS + SQLi via search
$search = isset($_GET['search']) ? $_GET['search'] : '';
$posts  = [];

if ($search !== '') {
    // ❌ VULNERABLE — raw $search injected into SQL
    $query = "SELECT posts.*, users.username FROM posts
              JOIN users ON posts.user_id = users.id
              WHERE posts.content LIKE '%$search%'
              ORDER BY posts.created_at DESC";
} else {
    $query = "SELECT posts.*, users.username FROM posts
              JOIN users ON posts.user_id = users.id
              ORDER BY posts.created_at DESC";
}

$result = mysqli_query($conn, $query);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $posts[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>VulnSocial — Feed</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav class="navbar">
    <div class="nav-logo">🔓 VulnSocial</div>
    <div class="nav-links">
        <a href="feed.php">Home</a>
        <a href="profile.php?id=<?= $user_id ?>">My Profile</a>
        <a href="messages.php">Messages</a>
        <a href="settings.php">Settings</a>
        <a href="logout.php" class="btn-logout">Logout</a>
    </div>
</nav>

<div class="container">
    <div class="main-grid">

        <!-- LEFT: Post Box -->
        <div class="sidebar-left">
            <div class="card profile-mini">
                <div class="avatar">👤</div>
                <strong><?= htmlspecialchars($username) ?></strong>
                <a href="profile.php?id=<?= $user_id ?>">View Profile</a>
            </div>
        </div>

        <!-- CENTER: Feed -->
        <div class="feed-col">

            <!-- ❌ CSRF vulnerable form — no token -->
            <div class="card post-box">
                <form method="POST" action="feed.php">
                    <textarea name="content" rows="3" placeholder="What's on your mind, <?= htmlspecialchars($username) ?>?"></textarea>
                    <div class="post-actions">
                        <button type="submit" class="btn btn-primary">Post</button>
                    </div>
                </form>
            </div>

            <!-- Search Bar — Reflected XSS + SQLi -->
            <div class="card search-box">
                <form method="GET" action="feed.php">
                    <!-- ❌ $search reflected without encoding -->
                    <input type="text" name="search" value="<?= $search ?>" placeholder="Search posts...">
                    <button type="submit" class="btn">Search</button>
                </form>
                <?php if ($search !== ''): ?>
                    <!-- ❌ Reflected XSS: $search echoed raw -->
                    <p class="search-label">Results for: <?= $search ?></p>
                <?php endif; ?>
            </div>

            <!-- Posts -->
            <?php if (empty($posts)): ?>
                <div class="card"><p class="empty">No posts found.</p></div>
            <?php else: ?>
                <?php foreach ($posts as $post): ?>
                <div class="card post-card">
                    <div class="post-header">
                        <a href="profile.php?id=<?= $post['user_id'] ?>">
                            <span class="avatar-sm">👤</span>
                            <strong><?= $post['username'] ?></strong>
                        </a>
                        <span class="post-time"><?= $post['created_at'] ?></span>
                    </div>
                    <!-- ❌ Stored XSS: content printed raw -->
                    <div class="post-body"><?= $post['content'] ?></div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- RIGHT: Hints -->
        <div class="sidebar-right">
            <div class="card vuln-panel">
                <h3>🔴 Vulnerabilities</h3>
                <ul>
                    <li>
                        <strong>SQLi (Search)</strong><br>
                        <code>?search=test' UNION SELECT 1,username,password,email,bio,role FROM users-- -</code>
                    </li>
                    <li>
                        <strong>Reflected XSS</strong><br>
                        <code>?search=&lt;script&gt;alert(1)&lt;/script&gt;</code>
                    </li>
                    <li>
                        <strong>Stored XSS</strong><br>
                        Post: <code>&lt;img src=x onerror=alert('XSS')&gt;</code>
                    </li>
                    <li>
                        <strong>CSRF</strong><br>
                        Post form has no CSRF token. See <code>csrf_poc.html</code>
                    </li>
                </ul>
            </div>
        </div>

    </div>
</div>
</body>
</html>
