<?php
// ===================================================
// register.php
// VULNERABILITY: Stored XSS via bio field
// Test: Put <script>alert('XSS')</script> in bio
// ===================================================
require_once 'db.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email    = $_POST['email'];
    $bio      = $_POST['bio']; // ❌ Stored XSS — not sanitized before saving OR display

    // Check duplicate
    $check = mysqli_query($conn, "SELECT id FROM users WHERE username='$username'");
    if (mysqli_num_rows($check) > 0) {
        $error = "Username already taken.";
    } else {
        // ❌ Password stored as plain text
        // ❌ No htmlspecialchars on bio
        $q = "INSERT INTO users (username, password, email, bio) VALUES ('$username','$password','$email','$bio')";
        mysqli_query($conn, $q);
        header("Location: login.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>VulnSocial — Register</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="auth-wrapper">
    <div class="auth-box">
        <div class="logo">🔓 VulnSocial</div>
        <p class="tagline">Create your account</p>

        <?php if ($error): ?>
            <div class="alert error"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST" action="register.php">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" placeholder="Choose a username">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" placeholder="your@email.com">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Choose a password">
            </div>
            <div class="form-group">
                <label>Bio</label>
                <textarea name="bio" rows="3" placeholder="Tell us about yourself..."></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Create Account</button>
        </form>

        <div class="auth-footer">
            Already have an account? <a href="login.php">Login</a>
        </div>

        <div class="vuln-hint">
            <strong>🔴 Stored XSS Hint:</strong><br>
            Put <code>&lt;script&gt;alert('XSS')&lt;/script&gt;</code> in the Bio field.<br>
            It will execute when anyone views your profile.
        </div>
    </div>
</div>
</body>
</html>
