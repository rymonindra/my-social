<?php
// ===================================================
// settings.php — Account Settings
// VULNERABILITY: CSRF — no token, no origin check
// An attacker can host csrf_poc.html on any domain
// and silently change victim's email/password when
// the victim visits the attacker's page while logged in.
//
// CSRF Test:
//   1. Login as alice
//   2. Open csrf_poc.html in another tab (or from attacker's server)
//   3. Click "Win Prize" button
//   4. alice's email is now changed to hacked@evil.com
// ===================================================
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$success = "";
$error   = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_email    = $_POST['email']    ?? '';
    $new_password = $_POST['password'] ?? '';
    $new_bio      = $_POST['bio']      ?? '';

    // ❌ No CSRF token checked
    // ❌ No current password verification
    // ❌ No sanitization

    if ($new_email) {
        mysqli_query($conn, "UPDATE users SET email='$new_email' WHERE id=$user_id");
        $success = "Email updated to: $new_email";
    }
    if ($new_password) {
        mysqli_query($conn, "UPDATE users SET password='$new_password' WHERE id=$user_id");
        $success .= " Password updated.";
    }
    if ($new_bio) {
        mysqli_query($conn, "UPDATE users SET bio='$new_bio' WHERE id=$user_id");
        $success .= " Bio updated.";
    }
}

// Fetch current user info
$me = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id=$user_id"));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>VulnSocial — Settings</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav class="navbar">
    <div class="nav-logo">🔓 VulnSocial</div>
    <div class="nav-links">
        <a href="feed.php">Home</a>
        <a href="profile.php?id=<?= $user_id ?>">My Profile</a>
        <a href="messages.php">Messages</a>
        <a href="settings.php" class="active">Settings</a>
        <a href="logout.php" class="btn-logout">Logout</a>
    </div>
</nav>

<div class="container">
    <div class="settings-wrapper">
        <div class="card settings-card">
            <h2>⚙️ Account Settings</h2>

            <?php if ($success): ?>
                <div class="alert success"><?= $success ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert error"><?= $error ?></div>
            <?php endif; ?>

            <!-- ❌ CSRF vulnerable — no hidden csrf token field -->
            <form method="POST" action="settings.php">
                <div class="form-group">
                    <label>Username (cannot change)</label>
                    <input type="text" value="<?= htmlspecialchars($me['username']) ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" value="<?= htmlspecialchars($me['email']) ?>">
                </div>
                <div class="form-group">
                    <label>New Password</label>
                    <input type="password" name="password" placeholder="Leave blank to keep current">
                </div>
                <div class="form-group">
                    <label>Bio</label>
                    <textarea name="bio" rows="4"><?= $me['bio'] ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </form>
        </div>

        <div class="card vuln-hint">
            <strong>🔴 CSRF Vulnerability:</strong><br>
            This form has <strong>no CSRF token</strong>.<br><br>
            Attack flow:<br>
            1. Victim logs into VulnSocial<br>
            2. Attacker sends victim a link to <code>csrf_poc.html</code><br>
            3. Victim clicks the page — their email silently changes<br><br>
            Open <code>csrf_poc.html</code> while logged in to demonstrate.
        </div>
    </div>
</div>
</body>
</html>
